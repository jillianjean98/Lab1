Lindsey Ma and Jillian Ritchey Lab 4

The goal is for Mario to collide with the star. If he makes it to the star, you win the game. If you collide with the block, you lose 100 points.
Control Mario with the arrow keys and the other controls from Lab 1. 